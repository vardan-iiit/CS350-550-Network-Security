from flask import Flask, request, jsonify,Response
from datetime import datetime
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography import x509
from cryptography.hazmat.backends import default_backend
import hashlib
from cryptography.hazmat.primitives.serialization import (
    load_pem_public_key,
    load_pem_private_key,
)
import base64
import json
import time
import binascii
from io import BytesIO
# import os
import pypdf

def encrypt_message(message, public_key):
    encrypted_message = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_message


def decrypt_message(encrypted_message, private_key):
    decrypted_message = private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_message.decode()


app = Flask(__name__)

import ntplib
from cryptography.exceptions import InvalidSignature

def get_trusted_time():
    # Specify the NTP server you want to query
    ntp_server = 'pool.ntp.org'

    try:
        # Create an NTP client
        client = ntplib.NTPClient()

        # Query the NTP server for the current time
        response = client.request(ntp_server)

        # Convert the NTP timestamp to a Unix timestamp (seconds since epoch)
        unix_timestamp = response.tx_time

        # Convert Unix timestamp to human-readable time
        human_readable_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(unix_timestamp))

        return unix_timestamp, human_readable_time
    except Exception as e:
        print("Error:", e)
        return None, None


# Load TSA's public key
with open("tsa_public_key.pem", "rb") as key_file:
    tsa_public_key = serialization.load_pem_public_key(
        key_file.read(), backend=default_backend()
    )

# Load clients' public key
with open("client_public_key.pem", "rb") as key_file:
    client_public_key = serialization.load_pem_public_key(
        key_file.read(), backend=default_backend()
    )

# Load TSA's private key
with open("tsa_private_key.pem", "rb") as key_file:
    tsa_private_key = serialization.load_pem_private_key(
        key_file.read(), password=None, backend=default_backend()
    )


# Function to generate a secure timestamp
def generate_timestamp(document_hash):
    timestamp = datetime.utcnow()
    ntp_timestamp, human_readable_time = get_trusted_time()
    if ntp_timestamp is not None:
        pass
    else:
        print("Failed to retrieve trusted time")
    timestamp_string = f"{human_readable_time}|{document_hash}"
    return timestamp_string.encode()





# Endpoint for timestamping documents
@app.route("/timestamptxt", methods=["POST"])

def timestamp_txt():
    file = request.files["txt"]
    document = file.read()
    
    document=decrypt_message(document,tsa_private_key)
    
    

    # Generate a secure timestamp
    timestamp = generate_timestamp(document)



    # Sign the timestamp with TSA's private key
    signature = tsa_private_key.sign(timestamp, padding.PKCS1v15(), hashes.SHA256())
    
    
    # Encode timestamp and signature to base64 strings
    timestamp_base64 = base64.b64encode(timestamp).decode()
    signature_base64 = base64.b64encode(signature).decode()
    encrpyttimestamp=encrypt_message(timestamp_base64,client_public_key)
    print("Timestamp:", timestamp_base64)
    print("Timestamp:", encrpyttimestamp)
    base64_string = base64.b64encode(encrpyttimestamp).decode()

    # Serialize to JSON
    json_data = json.dumps({"byte_data": base64_string})
    
    
   

    # Return JSON response
    return jsonify(
        {
            "timestamp": timestamp_base64,
            "signature": signature_base64,
        }
    )


@app.route("/timestamppdf", methods=["POST"])
def timestamp_pdf():
    file = request.files["pdf"]
    document = file.read()
    
    document=decrypt_message(document,tsa_private_key)
    
    



    # Generate a secure timestamp
    timestamp = generate_timestamp(document)

    # Sign the timestamp with TSA's private key
    signature = tsa_private_key.sign(timestamp, padding.PKCS1v15(), hashes.SHA256())

    # Encode timestamp and signature to base64 strings
    timestamp_base64 = base64.b64encode(timestamp).decode()
    signature_base64 = base64.b64encode(signature).decode()

    encrpyttimestamp=encrypt_message(timestamp_base64,client_public_key)
    print("Timestamp:", timestamp_base64)
    print("Timestamp:", encrpyttimestamp)
    print("Signature:", signature_base64)

    # Return JSON response
    return jsonify(
        {
            "timestamp": timestamp_base64,
            "signature": signature_base64,
        }
    )

# Endpoint for verifying timestamps
@app.route("/verify", methods=["POST"])
def verify_timestamp():
    data = request.files['json']
    data= data.read()
    json_data = json.loads(data)
    
       
    # Decode base64 encoded timestamp and signature
    timestamp_base64 = json_data["timestamp"]
    signature_base64 = json_data["signature"]

    
    
    # Decode base64 strings to bytes
    timestamp= base64.b64decode(timestamp_base64)
    signature = base64.b64decode(signature_base64)

   
   
    
    # document_hash = timestamp.split("|")[1]
    
    # print("Document hash:", document_hash)
    

    try:
        tsa_public_key.verify(
            signature,
            timestamp,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return jsonify({"verified": True, "message": "Timestamp signature verified"})
    except InvalidSignature:
        return jsonify({"verified": False, "message": "Invalid signature"})


if __name__ == "__main__":
    app.run(debug=True)
