import requests
import json
import hashlib
from cryptography.hazmat.backends import default_backend
import base64
import pypdf
import time
from io import BytesIO
from cryptography.hazmat.primitives.serialization import (
    load_pem_public_key,
    load_pem_private_key,
 
)

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization

# Load TSA's public key
with open("tsa_public_key.pem", "rb") as key_file:
    tsa_public_key = serialization.load_pem_public_key(
        key_file.read(), backend=default_backend()
    )
# Load your's private key
with open("client_private_key.pem", "rb") as key_file:
    client_private_key = serialization.load_pem_private_key(
        key_file.read(),password=None, backend=default_backend()
    )

def encrypt_message(message, public_key):
    encrypted_message = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_message


def decrypt_message(encrypted_message, private_key):
    decrypted_message = private_key.decrypt(
        encrypted_message,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_message.decode()




def hash_file(file_data):
    
    file_hash = hashlib.sha256(file_data).hexdigest()
    return file_hash

def upload_file(filepath):
    if filepath.split(".")[-1] == "pdf":
        
        with open(filepath, "rb") as file:
            
            pdffile = pypdf.PdfReader(BytesIO(file.read()))
            document = ""
            for page in pdffile.pages:
                document += page.extract_text()
           
            file=hash_file(document.encode())    
            file=encrypt_message(file, tsa_public_key)
            response = requests.post(
                "http://127.0.0.1:5000/timestamppdf", files={"pdf": file}
            )

        if response.ok:
            print("File uploaded successfully")

            with open(filepath.split(".")[0]+"_timestamped.json", "w") as f:
                json.dump(response.json(), f)
            
            print("Server response:", response.json())
            return True
        else:
            print("Failed to upload file")
            return False
    elif filepath.split(".")[-1] == "txt":
        
        with open(filepath, "rb") as file:
            file=hash_file(file.read())
            file=encrypt_message(file, tsa_public_key)
            response = requests.post(
                "http://127.0.0.1:5000/timestamptxt", files={"txt": file}
            )

        if response.ok:


            print("File uploaded successfully")
            

            with open(filepath.split(".")[0]+"_timestamped.json", "w") as f:
                json.dump(response.json(), f)
            

            print("Server response:", response.json())
            return True
        else:
            print("Failed to upload file")
            return False
    else:
        print("Invalid file format")
        return False


def verify_file(filepath,doc):
    if filepath.split(".")[-1] == "json":
        
        with open(filepath, "rb") as file:

            current_hash = None
            if doc.split(".")[-1] == "pdf":
                with open(doc, "rb") as file1:
                
                    pdffile = pypdf.PdfReader(BytesIO(file1.read()))
                    document = ""
                    for page in pdffile.pages:
                        document += page.extract_text()
                
                    current_hash=hash_file(document.encode()) 
                    
                    file1.close()  

            elif doc.split(".")[-1] == "txt":
                with open(doc, "rb") as file1:
                    current_hash=hash_file(file1.read())
                    
                    file1.close()
            
            data = file.read()  # Read the contents of the file
            file = json.loads(data)
            timestamp_base64 = file["timestamp"]
            signature_base64 = file["signature"]

            
            
            # Decode base64 strings to bytes
            timestamp= base64.b64decode(timestamp_base64)
            signature = base64.b64decode(signature_base64)

            timestamp_parts = timestamp.split(b'|')
            
            # Assuming the hash is always the second part
            document_hash = timestamp_parts[1]
            print(document_hash,"------------",current_hash.encode())
            if document_hash == current_hash.encode():

            

                try:
                    tsa_public_key.verify(
                        signature,
                        timestamp,
                        padding.PKCS1v15(),
                        hashes.SHA256()
                    )
                
                    print("File verified successfully")
                    return True
                except:
                    print("Digital Signature Verification Failed")
                    return False
            else :
                print("Integrity Verification Failed")
                return False

        # if response.ok:
        #     print("File verified successfully")
        #     print("Server response:", response.json())
        #     return True
        # else:
        #     print("Failed to verify file")
        #     return False
    


def main():
    while True:
        query = input("=> ")

        if query == "exit":
            break

        if query.startswith("timestamp"):
            filepath = query.split(" ")[1]
            upload_file(filepath)
        elif query.startswith("verify"):
            filepath = query.split(" ")[1]
            doc=query.split(" ")[2]
            

            
            verify_file(filepath,doc)


if __name__ == "__main__":
    main()
